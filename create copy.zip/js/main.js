var test = prompt('text:','');


document.write('<fieldset><textarea id="copy" type="text">'+test+'</textarea> </fieldset> <br /> <hr />'+


'<button onclick="copy()">copy</button>');









