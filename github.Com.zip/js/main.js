function get_1() {
    var x1 = document.getElementsByTagName('select') ,  
x2 = document.getElementsByTagName('input'); document.getElementsByTagName('textarea')[0].innerHTML = '<'+x1[0].value+'>&#10;'+x2[0].value+'&#10;</'+x1[0].value+'>';

}















